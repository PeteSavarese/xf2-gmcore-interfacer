(() => {
	'use strict'

	XF.Shoutbox = XF.Element.newHandler({
		init: function () {
			this.pollUrl = this.target.dataset.pollUrl || '/shoutbox/poll'
			this.sendUrl = this.target.dataset.sendUrl || '/shoutbox/sendmessage'
			this.olderUrl = this.target.dataset.olderUrl || '/shoutbox/older'
			this.entries = this.target.querySelector('.shoutbox-entries')
			this.input = this.target.querySelector('#shoutbox_input_message')
			this.sendButton = this.target.querySelector('#shoutbox_send_msg_button')
			this.messageBox = this.target.querySelector('.shoutbox-messages-box')
			this.lastId = this.getLastIdFromDom()
			this.loadingOlder = false
			this.hasMoreOlder = true
			this.generation = 0
			this.stopped = false
			this.pollInFlight = false
			this.initialLoadComplete = false
			this.sendInFlight = false
			this.lastSentText = null
			this.lastSentAt = 0
			this._shoutboxHeightHandle = createShoutboxHeightHandle(this)

			if (this.input) {
				this.input.addEventListener('keypress', (e) => {
					if (e.key === 'Enter') {
						e.preventDefault()
						this.sendMessage()
					}
				})
			}

			if (this.sendButton) {
				this.sendButton.addEventListener('click', (e) => {
					e.preventDefault()
					this.sendMessage()
				})
			}

			XF.on(document, 'ajax:complete', (e) => {
				const data = e.data
				if (data && data.shoutboxRefresh) {
					// Add small delay to ensure server has committed the transaction
					setTimeout(() => this.loadLatest(), 150)
				}
			})

			document.addEventListener('visibilitychange', () => {
				if (document.hidden) {
					this.stopped = true
				} else {
					this.stopped = false
					this.poll()
				}
			})

			if (this.messageBox) {
				this.messageBox.addEventListener('scroll', () => {
					// When scrolled to top, fetch older history.
					if (this.messageBox.scrollTop <= 0) {
						this.loadOlder()
					}
				})
			}

			this.initialAutoScroll()
			// Do an immediate poll, then poll periodically every 3 seconds.
			this.poll()
			this._pollInterval = setInterval(() => { if (!this.stopped) { this.poll() } }, 3000)
		},

		getFirstIdFromDom: function () {
			if (!this.entries) { return 0 }
			const first = this.entries.querySelector('li[data-messageid]')
			return first ? parseInt(first.dataset.messageid || '0', 10) : 0
		},

		loadOlder: function () {
			if (this.loadingOlder) { return }
			if (!this.hasMoreOlder) { return }
			if (!this.entries || !this.messageBox) { return }

			const beforeId = this.getFirstIdFromDom()
			if (!beforeId) { return }

			this.loadingOlder = true

			const prevScrollTop = this.messageBox.scrollTop
			const prevScrollHeight = this.messageBox.scrollHeight

			XF.ajax('GET', this.olderUrl, { before_id: beforeId, limit: 50 }, (data) => {
				if (!data) { return }

				const html = (this.getHtmlFromResponse(data) || '').trim()
				if (!html) {
					this.hasMoreOlder = false
					return
				}

				const tempDiv = document.createElement('div')
				tempDiv.innerHTML = html

				// Prepend nodes in their existing order.
				const nodes = Array.from(tempDiv.childNodes)
				for (let i = nodes.length - 1; i >= 0; i--) {
					this.entries.insertBefore(nodes[i], this.entries.firstChild)
				}

				XF.activate(this.entries)
				XF.DynamicDate.refresh(this.entries)

				// Preserve scroll position after prepending.
				const newScrollHeight = this.messageBox.scrollHeight
				const delta = newScrollHeight - prevScrollHeight
				this.messageBox.scrollTop = prevScrollTop + delta

				if (data.has_more === false) {
					this.hasMoreOlder = false
				}
			}, { skipDefault: true, global: false })
				.finally(() => {
					this.loadingOlder = false
				})
		},

		initialAutoScroll: function () {
			if (this.initialLoadComplete) {
				return
			}

			// Defer until layout is ready.
			setTimeout(() => {
				this.scrollToBottom()
				this.initialLoadComplete = true
			}, 0)
		},

		isNearBottom: function (thresholdPx = 80) {
			if (!this.messageBox) {
				return true
			}

			const el = this.messageBox
			const distance = el.scrollHeight - (el.scrollTop + el.clientHeight)
			return distance <= thresholdPx
		},

		getHtmlFromResponse: function (data) {
			if (!data) { return '' }
			if (typeof data.messages_html === 'string') { return data.messages_html } 			// Server returns `messages_html` since XF ajax reserves 'html'
			if (data.html == null) { return '' }

			const html = data.html
			if (typeof html === 'string') { return html }

			// XF ajax responses sometimes wrap HTML as an object, e.g. { content: "..." }
			if (typeof html === 'object') {
				if (typeof html.content === 'string') {
					return html.content
				}
				if (typeof html.html === 'string') {
					return html.html
				}
			}

			return ''
		},

		getLastIdFromDom: function () {
			if (!this.entries) { return 0 }

			const last = this.entries.querySelector('li[data-messageid]:last-child')
			return last ? parseInt(last.dataset.messageid || '0', 10) : 0
		},

		scrollToBottom: function () {
			if (this.messageBox) {
				this.messageBox.scrollTop = this.messageBox.scrollHeight
			}
		},

		loadLatest: function () {
			// if (this.pollInFlight) { return }
			this.pollInFlight = true

			XF.ajax('GET', this.pollUrl, { load: 1, generation: this.generation }, (data) => {
				if (!data || !this.entries) { return }

				const wasNearBottom = this.isNearBottom()
				const previousLastId = this.lastId
				const html = (this.getHtmlFromResponse(data) || '').trim()

				this.entries.innerHTML = html
				const newLastId = data.last_id || this.getLastIdFromDom()
				this.lastId = newLastId
				if (data.generation) {
					this.generation = data.generation
				}
				XF.activate(this.entries)
				XF.DynamicDate.refresh(this.entries)

				// Do not snap to bottom on overlay refreshes unless it also introduced new
				// messages AND the user was already at the bottom.
				const hasNew = (newLastId > previousLastId)

				if (hasNew && wasNearBottom) {
					this.scrollToBottom()
				}
			}, { skipDefault: true, global: false })
				.finally(() => { this.pollInFlight = false })
		},

		poll: function () {
			if (this.stopped || this.pollInFlight) { return }

			this.pollInFlight = true
			const wasNearBottom = this.isNearBottom()
			const previousLastId = this.lastId

			XF.ajax('GET', this.pollUrl, { last_id: this.lastId, generation: this.generation }, (data) => {
				if (!data) { return }

				const html = (this.getHtmlFromResponse(data) || '').trim()
				const newLastId = data.last_id || previousLastId
				const hasNew = (newLastId > previousLastId)

				if (data.mode === 'replace') {
					this.entries.innerHTML = html
					this.lastId = newLastId || this.getLastIdFromDom()

					if (data.generation) {
						this.generation = data.generation
					}

					XF.activate(this.entries) // Activate to have edit/delete/ban dropdown appear
					XF.DynamicDate.refresh(this.entries)

					// If this "replace" contained new messages, scroll only if the user
					// was already at the bottom.
					if (hasNew && wasNearBottom) {
						this.scrollToBottom()
					}

					return
				}

				if (html && this.entries) {
					const tempDiv = document.createElement('div')
					tempDiv.innerHTML = html
					while (tempDiv.firstChild) {
						this.entries.appendChild(tempDiv.firstChild)
					}
					this.lastId = newLastId || this.lastId
					if (data.generation) {
						this.generation = data.generation
					}
					XF.activate(this.entries)
					XF.DynamicDate.refresh(this.entries)

					// Scroll when new messages are appended (but only if user was already
					// near the bottom to avoid yanking them while reading history).
					if (hasNew && wasNearBottom) {
						this.scrollToBottom()
					}
				}
			}, { skipDefault: true, global: false })
				.finally(() => {
					this.pollInFlight = false
					// No recursive long-polling. Periodic polling via setInterval handles repeated requests.
				})
		},

		sendMessage: function () {
			if (!this.input) { return }
			if (this.sendInFlight) { return }
			if (this.input.disabled) { return }
			const value = (this.input.value || '').trim()
			if (!value) { return }

			// Simple client-side anti-spam: prevent rapid re-sends of the exact same text.
			const now = Date.now()
			if (this.lastSentText !== null
				&& value === this.lastSentText
				&& (now - this.lastSentAt) < 3000
			) {
				return
			}

			// Nonce for server-side de-dupe in case of client timeout / user double-click.
			const clientNonce = now.toString(36) + Math.random().toString(36).slice(2, 10)

			this.sendInFlight = true
			this.input.disabled = true
			this.input.classList.add('disabled')
			if (this.sendButton) {
				this.sendButton.classList.add('disabled')
				this.sendButton.setAttribute('aria-disabled', 'true')
			}

			const formData = new FormData()
			formData.append('message', value)
			formData.append('client_nonce', clientNonce)

			XF.ajax('POST', this.sendUrl, formData, () => {
				this.lastSentText = value
				this.lastSentAt = now
				// Refresh is handled by ajax:complete event with shoutboxRefresh flag
			})
				.finally(() => {
					this.sendInFlight = false
					this.input.disabled = false
					this.input.classList.remove('disabled')
					if (this.sendButton) {
						this.sendButton.classList.remove('disabled')
						this.sendButton.removeAttribute('aria-disabled')
					}
					this.input.value = ''
				})
		}
	})

	XF.ShoutboxHandleEmojis = XF.Element.newHandler({
		init: function () {
			const menu = this.target
			const container = menu.closest('.shoutbox_box_main') || document
			const inputShoutField = container.querySelector('#shoutbox_input_message')
			const trigger = menu.previousElementSibling
			let observer = null

			const insertAtCursor = (input, text) => {
				if (!input) { return }
				const toInsert = (text || '').trim()
				if (!toInsert) { return }

				const insertText = toInsert + ' '
				const start = (typeof input.selectionStart === 'number') ? input.selectionStart : (input.value || '').length
				const end = (typeof input.selectionEnd === 'number') ? input.selectionEnd : (input.value || '').length
				const current = input.value || ''

				input.value = current.slice(0, start) + insertText + current.slice(end)

				try {
					const pos = start + insertText.length
					input.setSelectionRange(pos, pos)
				} catch (e) { /* ignore */ }

				input.focus()
				input.dispatchEvent(new Event('input', { bubbles: true }))
			}

			const lazyLoadEmoji = (toLoad) => {
				if (!toLoad || toLoad.tagName !== 'SPAN') { return }
				if (!toLoad.classList || !toLoad.classList.contains('smilie--lazyLoad')) { return }

				const image = XF.createElement('img', {
					className: toLoad.getAttribute('class').replace(/(\s|^)smilie--lazyLoad(\s|$)/, ' '),
					alt: toLoad.getAttribute('data-alt'),
					title: toLoad.getAttribute('title'),
					src: toLoad.getAttribute('data-src'),
					dataset: { shortname: toLoad.dataset.shortname }
				})

				const replace = () => {
					window.requestAnimationFrame(() => {
						toLoad.outerHTML = image.outerHTML
					})
				}

				if (image.complete) {
					XF.on(image, 'load', replace)
				} else {
					replace()
				}
			}

			const ensureLazyLoad = () => {
				const menuScroll = menu.querySelector('.menu-scroller') || menu.querySelector('.menu-content')
				if (!menuScroll || typeof IntersectionObserver === 'undefined') {
					// Fallback: if there's no observer support, try to eagerly load everything.
					menu.querySelectorAll('span.smilie--lazyLoad').forEach(lazyLoadEmoji)
					return
				}

				if (!observer) {
					observer = new IntersectionObserver((changes, obs) => {
						for (const entry of changes) {
							if (!entry.isIntersecting) { continue }
							lazyLoadEmoji(entry.target)
							obs.unobserve(entry.target)
						}
					}, {
						root: menuScroll,
						rootMargin: '0px 0px 100px 0px'
					})
				}

				menu.querySelectorAll('span.smilie--lazyLoad').forEach(smilie => observer.observe(smilie))
			}

			// Insert emoji / smilie shortnames into the shoutbox input.
			XF.on(menu, 'click', (e) => {
				const emojiLink = e.target.closest('.js-emoji')
				if (!emojiLink || !menu.contains(emojiLink) || !inputShoutField) {
					return
				}
				e.preventDefault()
				insertAtCursor(inputShoutField, emojiLink.dataset.shortname)
			})

			// When the menu finishes loading/opening, activate lazy-load.
			if (trigger) {
				XF.on(trigger, 'menu:complete', ensureLazyLoad)
			}
			XF.on(menu, 'menu:opened', ensureLazyLoad)
		}
	})

	XF.Element.register('shoutbox', 'XF.Shoutbox')
	XF.Element.register('shoutbox-emoji-button', 'XF.ShoutboxHandleEmojis')

	function createShoutboxHeightHandle(parent) {
		const MIN_HEIGHT = 150
		const MAX_HEIGHT = 635

		let isResizing = false
		let initialPageY = 0
		let startHeight = 0

		const box = parent.messageBox || parent.entries || parent.target
		if (!box) return null

		// Apply saved height if present
		const saved = parseInt(localStorage.getItem('shoutboxHeight'), 10)
		if (!Number.isNaN(saved)) {
			box.style.height = saved + 'px'
		}

		const button = (parent.target && parent.target.querySelector)
			? parent.target.querySelector('#shoutbox_resize_button')
			: document.getElementById('shoutbox_resize_button')
		if (!button) return null

		const onMouseMove = (e) => {
			if (!isResizing) return

			let delta = e.pageY - initialPageY
			let newH = startHeight + delta

			if (newH < MIN_HEIGHT) newH = MIN_HEIGHT
			if (newH > MAX_HEIGHT) newH = MAX_HEIGHT

			box.style.height = newH + 'px'

			box.scrollTop = box.scrollHeight
		}

		const onMouseUp = () => {
			if (!isResizing) return

			isResizing = false
			document.removeEventListener('mousemove', onMouseMove)
			document.removeEventListener('mouseup', onMouseUp)

			const shoutboxHeight = parseInt(box.style.height, 10)
			if (!Number.isNaN(shoutboxHeight)) {
				localStorage.setItem('shoutboxHeight', shoutboxHeight)
			}
		}

		button.addEventListener('mousedown', (e) => {
			e.preventDefault()

			isResizing = true
			startHeight = box.clientHeight
			initialPageY = e.pageY

			document.addEventListener('mousemove', onMouseMove)
			document.addEventListener('mouseup', onMouseUp)
		})
	}
})()