<?php
namespace Shoutbox\Helper;

class Shoutbox {
  public function regenerateShoutboxHTML() {
    \XF\Util\File::createDirectory('data/tkgmod', true); // Make the directory where the .txt file will be stored

    $db = \XF::db();
    $html = time(); // HTML which gets concated in the foreach loop; time() hacky way for jquery to determine the last updated time, and whether to refresh the shoutbox html

    $shouts = $db->fetchAll("SELECT * FROM shoutbox");

    // TODO: Actually do this correctly with a template. This'll do for now with inline HTML. Its shit but hey
    foreach ($shouts as $key => $message) {
      //var_dump($shouts);
    $finder = \XF::finder('XF:User'); // Getting user instance by ID in foreach loop
      $user = $finder->where('user_id', $message['user_id'])->fetchOne();

      if (is_null($user) OR $user == false) {
        return false;
      }

      $html .= "<li data-messageid='{$message['id']}'>"; // Begin a new line of shout message

      // Add avatar html autogened by $avatar templater func
      $avatarArgs = [$user, 'xxs']; // Used for the avatar size
      $avatar = \XF::app()->templater()->func('avatar', $avatarArgs); // Autogens avatar by fetching avatar template
      $html .= $avatar . " ";

      // Add timestamp
      $time = \XF::app()->templater()->func('date_dynamic', [$message['date']]);
      $html .= $time . " ";

      $username = \XF::app()->templater()->func('username_link', array($user, true));
      $html .= $username . ": ";

      // Add their message, converting from BBCode to html
      $html .= "<span>" . \XF::app()->templater()->func('bb_code', [$message['message'], 'post', []]) . "</span>";

      $html .= "</li>"; // Everythign in this line has been completed
    }

    return \XF\Util\File::writeFile("data/tkgmod/shoutbox.txt", $html, false);
  }
}
