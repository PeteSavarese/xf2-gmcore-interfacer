<?php

namespace Shoutbox\Widget;

class Shoutbox extends \XF\Widget\AbstractWidget {
  public function render() {

		return $this->renderer('shoutbox_full_box', [

		]);
	}
}
