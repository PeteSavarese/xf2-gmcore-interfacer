<?php

namespace Shoutbox\XF\Entity;

class User extends XFCP_User {
  public function isBannedFromShoutbox() {
    $db = \XF::db();

    $userId = $this["user_id"];

    $bannedUserId = $db->fetchOne('SELECT user_id FROM shoutbox_bans WHERE user_id = ?', $userId);

    // If we aren't false, the UserID was found and the user is banned
    if ($bannedUserId != false) {
      return true;
    }

    return false;
  }
}
