<?php
namespace Shoutbox\Pub\Controller;

use Shoutbox\Helper\Shoutbox;
use XF;
use XF\Mvc\ParameterBag;

class Index extends AbstractController
{
    public function actionIndex()
    {
        return $this->view("", "shoutbox_full_box", []);
    }

    public function actionSendmessage(ParameterBag $params)
    {
        $db = XF::db();
        $user = XF::visitor();
        $this->assertPostOnly();
        $shoutboxHelper = new Shoutbox;
        $reply = $this->view();

        if (is_null($user->user_id) OR $user->user_id < 1) {
            return $this->error("You must be logged in to post messages to the shoutbox.");
        }

        // Check if we submitted not a blank message
        if (isset($_POST['message'])) {
            $message = $_POST['message'];
        } else {
            return $this->error("Please enter a valid message");
        }

        if ($user->isBannedFromShoutbox()) {
            return $this->error("You are banned from posting in the shoutbox.");
        }

        if ($message == "!forceupdate") {
            // Force the shoutbox to update the .txt file
            if ($user->hasPermission('tkgmod', 'force_update') == false) {
                $reply->setJsonParams([
                    'message' => "You don't have permission to force the shoutbox file to update.",
                ]);

                return $reply;
            }

            $shoutboxHelper->regenerateShoutboxHTML();
            $reply->setJsonParams([
                'message' => "Shoutbox .txt file forced to update",
            ]);

            return $reply;
        }

        $db->insert('shoutbox', [
            'user_id' => $user['user_id'],
            'date' => time(),
            'message' => $message
        ]);

        $shoutboxHelper->regenerateShoutboxHTML();

        $reply->setJsonParams([
            'message' => $message,
        ]);

        return $reply;
    }
}

?>
